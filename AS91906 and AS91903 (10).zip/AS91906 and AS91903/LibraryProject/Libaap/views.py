# The views file contains functions that control which data is shown on each webpage and which HTML template is being displayed on the website
from django.shortcuts import render
from django.shortcuts import redirect, render
from .models import Book
from django.core.exceptions import ValidationError
from django.contrib.auth.hashers import check_password
from django.shortcuts import redirect, render
from .models import Book, Register
# Create your views here.
def home (request):
    return render(request, 'home.html')
def books(request):
    books = Book.objects.all() # This line of code retrieves all books from the database
    return render(request, 'books.html', {'books': books})
def register(request):
    if request.method == "POST":
        User_ID = request.POST.get("User_ID")
        User_name = request.POST.get("User_name")
        Email = request.POST.get("Email")
        Password = request.POST.get("Password")
        Confirm_password = request.POST.get("Confirm_password")
        # Check passwords match
        if Password != Confirm_password:
            return render(request, "register.html", {
                "errors": {
                    "password": ["Passwords do not match."]
                },
                "User_ID": User_ID,
                "User_name": User_name,
                "Email": Email,
            }) 
        Student = Register(
            User_ID=User_ID,
            User_name=User_name,
            Email=Email,
            Password=Password
        )
        try:
            # Runs your model clean() validation
            Student.full_clean()
            # Saves into Student table
            Student.save()
            # Go to login page after success
            return redirect("login")
        except ValidationError as e:
            return render(request, "register.html", {
                "errors": e.message_dict,
                "User_ID": User_ID,
                "User_name": User_name,
                "Email": Email,
            })
    return render(request, "register.html")
def login(request):
    if request.method == "POST":
        Email = request.POST.get("Email")
        Password = request.POST.get("Password")
        try:
            # Search Student table using email
            Student = Register.objects.get(Email=Email)
            # Check password against stored hashed password
            if check_password(Password, Student.Password):
                # Store logged-in student details in session
                request.session['Student_id'] = Student.User_ID
                request.session['Student_name'] = Student.User_name
                # Login successful
                return redirect("home")
            else:
                # Wrong password
                return render(request, "login.html", {
                    "error": "Incorrect password. Please try again."
                })
        except Register.DoesNotExist:
            # Email does not exist
            return render(request, "login.html", {
                "error": "Email is not registered."
            })
    return render(request, "login.html")



