from django.apps import AppConfig


class LibaapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Libaap'
