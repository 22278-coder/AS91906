# My imports
from django.db import models
from django.db import models, transaction
from django.core.exceptions import ValidationError
# My model classes
# Book class
class Book(models.Model):
    Book_ID = models.AutoField(primary_key=True)
    Book_Title = models.CharField(max_length=100)
    Publish_Date = models.DateField(max_length=100)
    Catogory = models.CharField(max_length=100)
    Author = models.CharField(max_length=50)
    copies_available = models.IntegerField(default=1)
    img = models.ImageField(upload_to='Images/', default='Images/download.jpg', null=True, blank=True)
    def __str__(self):
        return f"{self.Book_Title} {self.Publish_Date} {self.Author}"
# Register class
class Register(models.Model):
    User_ID = models.AutoField(primary_key=True)
    User_name = models.CharField(max_length=100)
    Email = models.EmailField(max_length=100)
    Password = models.CharField(default='')
    def clean(self):
     if not self.User_name.isalpha():
      raise ValidationError("Username must contain only letters")
     if not self.Email.endswith("@gmail.com"):
        raise ValidationError("Email must end with @gmail.com")
    def __str__(self):
        return f"{self.User_name} {self.Email}"
# Catogory class
class Catogorie(models.Model):
    Genre = models.CharField(max_length=50)
    Fiction_NonFiction = models.CharField(max_length=50)
    Adult_Kid = models.CharField(max_length=50)
    User_Group = models.CharField(max_length=50)
    def __str__(self):
        return f"{self.Genre} {self.Fiction_NonFiction} {self.Adult_Kid}"