# This file guides the URL routes of the project and connects them to the corresponding app or views
from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("books/", views.books, name="books"),
    path("login/", views.login, name="login"),
    path("register/", views.register, name="register"),

]