# The views file contains functions that control which data is shown on each webpage and which HTML template is being displayed on the website
from django.shortcuts import render
from django.shortcuts import redirect, render
from .models import Book
from django import ValidationError
from django.contrib.auth.hashers import check_password
from django.shortcuts import redirect, render
from .models import Book, Student

# Create your views here.
def home (request):
    return render(request, 'home.html')

def books(request):
    books = Book.objects.all() # This line of code retrieves all books from the database
    return render(request, 'books.html', {'books': books})

def register(request):
    if request.method == "POST":
        User_ID = request.POST.get("User_ID")
        User_name = request.POST.get("User_name")
        Email = request.POST.get("Email")
        Phone_number = request.POST.get("Phone_number")
        Password = request.POST.get("Password")
        Confirm_password = request.POST.get("Confirm_password")




        # Check passwords match
        if Password != Confirm_password:
            return render(request, "register.html", {
                "errors": {
                    "password": ["Passwords do not match."]
                },
                "User_ID": User_ID,
                "User_name": User_name,
                "Email": Email,
                "Phone_number": Phone_number
            })
        student = Student(
            User_ID=User_ID,
            User_name=User_name,
            Email=Email,
            Phone_number=Phone_number,
            Password=Password
        )
        try:
            # Runs your model clean() validation
            student.full_clean()


            # Saves into Student table
            student.save()


            # Go to login page after success
            return redirect("login")




        except ValidationError as e:


            return render(request, "register.html", {
                "errors": e.message_dict,
                "User_ID": User_ID,
                "User_name": User_name,
                "Email": Email,
                "Phone_number": Phone_number
            })
    return render(request, "register.html")


