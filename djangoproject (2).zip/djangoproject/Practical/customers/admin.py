from django.contrib import admin
from .models import Book, Register, Catogorie

# Register models are here
admin.site.register(Book)
admin.site.register(Register)
admin.site.register(Catogorie)